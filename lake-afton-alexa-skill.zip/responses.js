module.exports = {
	responses: {
		'test':'test 1',
		'test2':'test 2'
	}
}
